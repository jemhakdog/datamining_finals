# School Management System

A comprehensive web-based school management system built with PHP and MySQL, featuring student, teacher, subject, and class management capabilities.

![Class Management](CRUDS/Class-Management.png)

## Features

- 👨‍🎓 **Student Management**: Enrollment, profiles, and course registration
- 👨‍🏫 **Teacher Management**: Department assignments and subject allocation
- 📚 **Subject Management**: Course creation and unit configuration
- 📅 **Class Management**: Student-subject mapping and enrollment
- 🎯 **Grade Management**: Record and track student performance

## Quick Start

### Option 1: Automated Setup (Recommended)

1. Ensure you have XAMPP, WAMP, or standalone PHP/MySQL installed
2. Double-click `run.bat` to:
   - Set up the database
   - Import required data
   - Start the development server
   - Open the application in your browser

### Option 2: Manual Setup

Follow our detailed [Setup Guide](setup_guide.md) for step-by-step instructions on:
- System requirements
- Database configuration
- Manual server startup
- Troubleshooting tips

## System Requirements

- PHP 7.3 or higher
- MySQL/MariaDB 5.7 or higher
- Web server (Apache/PHP built-in server)
- Web browser (Chrome/Firefox/Edge)

## Default Login

- Username: admin
- Password: admin123

## Screenshots

### Teacher Management
![Teacher Management](CRUDS/Teacher-Management.png)

### Subject Management
![Subject Management](CRUDS/Subject-Management.png)

### Grade Management
![Grade Management](CRUDS/Grade-Management.png)

## Releases

You can download the latest version of the School Management System from our [GitHub Releases](https://github.com/username/school-management-system/releases) page. Each release includes:

- Source code (zip/tar.gz)
- Pre-configured database
- Release notes with changes and improvements
- Installation instructions

### Latest Version: v1.0.0

Key features in this release:
- Complete student management system
- Teacher and subject management
- Class scheduling and enrollment
- Grade management and tracking
- Automated setup script
- Comprehensive documentation

## Need Help?

Refer to our [Setup Guide](setup_guide.md) for detailed instructions and troubleshooting tips.